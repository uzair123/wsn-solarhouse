#ifndef __CO_SENSOR_H__
#define __CO_SENSOR_H__

#include "lib/sensors.h"

extern const struct sensors_sensor CO_sensor;

#define CO_SENSOR "CO"


#endif /* __CO_SENSOR_H__ */
