#ifndef __HUMIDITY_SENSOR_H__
#define __HUMIDITY_SENSOR_H__

#include "lib/sensors.h"

extern const struct sensors_sensor humidity_sensor;

#define HUMIDITY_SENSOR "Humidity"


#endif /* __HUMIDITY_SENSOR_H__ */
